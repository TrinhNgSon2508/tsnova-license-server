import psutil

import customtkinter as ctk

from core.app_state import (
    app_state
)


MAX_WORKERS = 4
try:

    import torch

except:

    torch = None


# =========================================================
# PERFORMANCE PANEL
# =========================================================

class PerformancePanel(ctk.CTkFrame):

    def __init__(
        self,
        parent
    ):

        super().__init__(
            parent
        )

        # =================================================
        # LAYOUT
        # =================================================

        self.pack(
            fill="x",
            padx=10,
            pady=10
        )

        # =================================================
        # TITLE
        # =================================================

        self.title_label = ctk.CTkLabel(

            self,

            text="Performance Monitor",

            font=ctk.CTkFont(
                size=18,
                weight="bold"
            )
        )

        self.title_label.pack(
            pady=(10, 15)
        )

        # =================================================
        # STATS LABEL
        # =================================================

        self.stats_label = ctk.CTkLabel(

            self,

            text="Loading...",

            justify="left",

            anchor="w",

            font=ctk.CTkFont(
                size=13
            )
        )

        self.stats_label.pack(
            fill="x",
            padx=15,
            pady=(0, 15)
        )

        # =================================================
        # START UPDATE LOOP
        # =================================================

        self.update_stats()

    # =====================================================
    # UPDATE STATS
    # =====================================================

    def update_stats(self):

        # =================================================
        # CPU
        # =================================================

        cpu_percent = psutil.cpu_percent()

        # =================================================
        # RAM
        # =================================================

        ram = psutil.virtual_memory()

        ram_used = ram.used / (1024 ** 3)

        ram_total = ram.total / (1024 ** 3)

        # =================================================
        # GPU
        # =================================================

        gpu_text = "GPU: N/A"

        vram_text = "VRAM: N/A"

        if (
            torch is not None
            and torch.cuda.is_available()
        ):

            gpu_name = torch.cuda.get_device_name(0)

            vram_used = (
                torch.cuda.memory_allocated(0)
                / (1024 ** 3)
            )

            vram_total = (
                torch.cuda.get_device_properties(0).total_memory
                / (1024 ** 3)
            )

            gpu_text = (
                f"GPU: {gpu_name}"
            )

            vram_text = (
                f"VRAM: "
                f"{vram_used:.2f} GB / "
                f"{vram_total:.2f} GB"
            )

        # =================================================
        # QUEUE
        # =================================================

        queue_count = len(
            app_state.image_paths
        )

        # =================================================
        # BUILD TEXT
        # =================================================

        text = (

            f"CPU: {cpu_percent}%\n"

            f"RAM: "
            f"{ram_used:.2f} GB / "
            f"{ram_total:.2f} GB\n"

            f"{gpu_text}\n"

            f"{vram_text}\n"

            f"Workers: {MAX_WORKERS}\n"

            f"Queue: {queue_count}"
        )

        self.stats_label.configure(
            text=text
        )

        # =================================================
        # LOOP
        # =================================================

        self.after(
            1000,
            self.update_stats
        )