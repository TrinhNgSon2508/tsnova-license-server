import customtkinter as ctk

from PIL import Image

import threading
import queue
import os
import tkinter as tk
import subprocess

from core.app_state import app_state


ui_queue = queue.Queue()

current_preview_container = None

image_refs = []


# =====================================================
# CLEAR PREVIEW
# =====================================================

def clear_preview(preview_container):

    global image_refs

    image_refs.clear()

    for widget in preview_container.winfo_children():
        widget.destroy()

    create_thumbnail_card.row = 0
    create_thumbnail_card.col = 0


# =====================================================
# TOGGLE SELECTION
# =====================================================

def toggle_selection(
    event,
    card,
    image_path
):

    shift_pressed = (
        event.state & 0x1
    )

    # =================================================
    # SHIFT SELECT
    # =================================================

    if (
        shift_pressed
        and app_state.last_selected
    ):

        try:

            paths = app_state.image_paths

            start = paths.index(
                app_state.last_selected
            )

            end = paths.index(
                image_path
            )

            if start > end:
                start, end = end, start

            selected_range = paths[
                start:end + 1
            ]

            app_state.selected_images.update(
                selected_range
            )

        except:
            pass

    # =================================================
    # NORMAL SELECT
    # =================================================

    else:

        if image_path in app_state.selected_images:

            app_state.selected_images.remove(
                image_path
            )

        else:

            app_state.selected_images.add(
                image_path
            )

    app_state.last_selected = image_path

    threaded_update_preview(
        app_state.image_paths,
        card.master
    )


# =====================================================
# DELETE IMAGE
# =====================================================

def delete_image(image_path):

    if image_path in app_state.image_paths:

        app_state.image_paths.remove(
            image_path
        )

    if image_path in app_state.selected_images:

        app_state.selected_images.remove(
            image_path
        )

    threaded_update_preview(
        app_state.image_paths,
        current_preview_container
    )


# =====================================================
# OPEN FOLDER
# =====================================================

def open_folder(image_path):

    folder = os.path.dirname(
        image_path
    )

    subprocess.Popen(
        f'explorer "{folder}"'
    )


# =====================================================
# CONTEXT MENU
# =====================================================

def show_context_menu(
    event,
    card,
    image_path
):

    menu = tk.Menu(
        tearoff=0
    )

    menu.add_command(
        label="Select",
        command=lambda: toggle_selection(
            event,
            card,
            image_path
        )
    )

    menu.add_separator()

    menu.add_command(
        label="Delete",
        command=lambda: delete_image(
            image_path
        )
    )

    menu.add_command(
        label="Open Folder",
        command=lambda: open_folder(
            image_path
        )
    )

    menu.tk_popup(
        event.x_root,
        event.y_root
    )


# =====================================================
# CREATE THUMBNAIL CARD
# =====================================================

def create_thumbnail_card(
    preview_container,
    image_path
):

    global image_refs

    try:

        pil_image = Image.open(
            image_path
        )

        pil_image.thumbnail(
            (140, 140)
        )

        ctk_image = ctk.CTkImage(
            light_image=pil_image,
            dark_image=pil_image,
            size=(140, 140)
        )

        image_refs.append(
            ctk_image
        )

        # =================================================
        # CARD
        # =================================================

        border_width = 0

        if image_path in app_state.selected_images:
            border_width = 3

        card = ctk.CTkFrame(
            preview_container,
            width=170,
            height=220,
            corner_radius=12,
            border_width=border_width,
            border_color="#3399ff"
        )

        card.grid(
            row=create_thumbnail_card.row,
            column=create_thumbnail_card.col,
            padx=10,
            pady=10,
            sticky="n"
        )

        create_thumbnail_card.col += 1

        if create_thumbnail_card.col >= 5:

            create_thumbnail_card.col = 0
            create_thumbnail_card.row += 1

        card.pack_propagate(False)

        # =================================================
        # IMAGE
        # =================================================

        image_label = ctk.CTkLabel(
            card,
            image=ctk_image,
            text=""
        )

        image_label.image = ctk_image

        image_label.pack(
            pady=(10, 5)
        )

        # =================================================
        # NAME
        # =================================================

        name_label = ctk.CTkLabel(
            card,
            text=os.path.basename(
                image_path
            ),
            wraplength=140
        )

        name_label.pack(
            padx=5,
            pady=(0, 10)
        )

        # =================================================
        # BIND EVENTS
        # =================================================

        widgets = [
            card,
            image_label,
            name_label
        ]

        # LEFT CLICK

        for widget in widgets:

            widget.bind(
                "<Button-1>",
                lambda e,
                c=card,
                p=image_path: toggle_selection(
                    e,
                    c,
                    p
                )
            )

        # RIGHT CLICK

        for widget in widgets:

            widget.bind(
                "<Button-3>",
                lambda e,
                c=card,
                p=image_path: show_context_menu(
                    e,
                    c,
                    p
                )
            )

    except Exception as e:

        print(
            f"[Preview Error] {e}"
        )


create_thumbnail_card.row = 0
create_thumbnail_card.col = 0


# =====================================================
# WORKER
# =====================================================

def preview_worker(
    image_paths,
    preview_container
):

    for image_path in image_paths:

        ui_queue.put(
            (
                image_path,
                preview_container
            )
        )


# =====================================================
# START THREAD
# =====================================================

def threaded_update_preview(
    image_paths,
    preview_container
):

    global current_preview_container

    current_preview_container = (
        preview_container
    )

    clear_preview(
        preview_container
    )

    worker = threading.Thread(
        target=preview_worker,
        args=(
            image_paths,
            preview_container
        ),
        daemon=True
    )

    worker.start()


# =====================================================
# PROCESS UI QUEUE
# =====================================================

def process_ui_queue():

    try:

        while True:

            (
                image_path,
                preview_container
            ) = ui_queue.get_nowait()

            create_thumbnail_card(
                preview_container,
                image_path
            )

    except queue.Empty:
        pass