import os
import customtkinter as ctk
import shutil

from tkinter import filedialog

from ui.queue_panel import QueuePanel
from ui.performance_panel import PerformancePanel
from ui.compare_slider import CompareSlider

from ui.preview_manager import (
    threaded_update_preview,
    process_ui_queue
)

from core.processing_worker import (
    start_processing_worker
)

from core.app_state import app_state


class PreviewPage(ctk.CTkFrame):

    def clear_selection(self):

        app_state.selected_images.clear()

        threaded_update_preview(
            app_state.image_paths,
            self.preview_container
        )

    def select_all(self):

        app_state.selected_images = set(
            app_state.image_paths
        )

        threaded_update_preview(
            app_state.image_paths,
            self.preview_container
        )

    def delete_selected(self):

        selected = list(
            app_state.selected_images
        )

        if not selected:
            return

        app_state.image_paths = [

            path for path in app_state.image_paths

            if path not in selected
        ]

        app_state.selected_images.clear()

        threaded_update_preview(
            app_state.image_paths,
            self.preview_container
        )

        self.queue_panel.refresh_queue()
        
    def __init__(self, parent):

        super().__init__(parent)

        start_processing_worker()

        self.build_ui()

    # =====================================================
    # BUILD UI
    # =====================================================

    def build_ui(self):

        # =================================================
        # TOP BAR
        # =================================================

        self.topbar = ctk.CTkFrame(
            self,
            height=60
        )

        self.topbar.pack(
            fill="x",
            padx=10,
            pady=10
        )

        self.topbar.pack_propagate(False)

        self.title_label = ctk.CTkLabel(
            self.topbar,
            text="TSNOVA Preview",
            font=("Arial", 24, "bold")
        )

        self.title_label.pack(
            side="left",
            padx=20
        )

        # =================================================
        # MAIN CONTENT
        # =================================================

        self.content = ctk.CTkFrame(self)

        self.content.pack(
            fill="both",
            expand=True,
            padx=10,
            pady=(0, 10)
        )

        # =================================================
        # LEFT PANEL
        # =================================================

        self.left_panel = ctk.CTkFrame(
            self.content
        )

        self.left_panel.pack(
            side="left",
            fill="both",
            expand=True,
            padx=(0, 10)
        )

        # =================================================
        # CONTROL BAR
        # =================================================

        self.control_bar = ctk.CTkFrame(
            self.left_panel,
            height=70
        )

        self.control_bar.pack(
            fill="x",
            padx=10,
            pady=10
        )

        self.control_bar.pack_propagate(False)

        # =================================================
        # SELECTION TOOLBAR
        # =================================================

        self.selection_bar = ctk.CTkFrame(
            self.left_panel,
            height=60
        )

        self.selection_bar.pack(
            fill="x",
            padx=10,
            pady=(0, 10)
        )

        self.selection_bar.pack_propagate(False)

        self.delete_selected_btn = ctk.CTkButton(
            self.selection_bar,
            text="Delete Selected",
            command=self.delete_selected
        )


        self.retry_selected_btn = ctk.CTkButton(
            self.selection_bar,
            text="Retry Selected",
            command=self.retry_selected
        )

        self.retry_selected_btn.pack(
            side="left",
            padx=10
        )

        self.compare_selected_btn = ctk.CTkButton(
            self.selection_bar,
            text="Compare Selected",
            command=self.compare_selected
        )

        self.compare_selected_btn.pack(
            side="left",
            padx=10
        )

        self.export_selected_btn = ctk.CTkButton(
            self.selection_bar,
            text="Export Selected",
            command=self.export_selected
        )

        self.export_selected_btn.pack(
            side="left",
            padx=10
        )

        self.selected_count_label = ctk.CTkLabel(
            self.selection_bar,
            text="Selected: 0"
        )

        self.selected_count_label.pack(
            side="right",
            padx=20
        )

        # =================================================
        # ADD BUTTON
        # =================================================

        self.add_button = ctk.CTkButton(
            self.control_bar,
            text="Add Images",
            command=self.add_images
        )

        self.add_button.pack(
            side="left",
            padx=10,
            pady=10
        )

        # =================================================
        # START BUTTON
        # =================================================

        self.start_button = ctk.CTkButton(
            self.control_bar,
            text="Start"
        )

        self.start_button.pack(
            side="left",
            padx=10,
            pady=10
        )

        # =================================================
        # STOP BUTTON
        # =================================================

        self.stop_button = ctk.CTkButton(
            self.control_bar,
            text="Stop"
        )

        self.stop_button.pack(
            side="left",
            padx=10,
            pady=10
        )

        self.delete_button = ctk.CTkButton(
            self.control_bar,
            text="Delete Selected",
            fg_color="#cc4444",
            command=self.delete_selected
        )

        self.delete_button.pack(
            side="left",
            padx=10,
            pady=10
        )

        self.select_all_button = ctk.CTkButton(
            self.control_bar,
            text="Select All",
            command=self.select_all
        )

        self.select_all_button.pack(
            side="left",
            padx=10,
            pady=10
        )

        self.clear_select_button = ctk.CTkButton(
            self.control_bar,
            text="Clear Select",
            command=self.clear_selection
        )

        self.clear_select_button.pack(
            side="left",
            padx=10,
            pady=10
        )

        # =================================================
        # PREVIEW AREA
        # =================================================

        self.preview_container = ctk.CTkScrollableFrame(
            self.left_panel,
            fg_color="#2b2b2b"
        )

        self.preview_container.pack(
            fill="both",
            expand=True,
            padx=15,
            pady=15
        )

        # =================================================
        # RIGHT PANEL
        # =================================================

        self.right_panel = ctk.CTkFrame(
            self.content,
            width=340
        )

        self.right_panel.pack(
            side="right",
            fill="y"
        )

        self.right_panel.pack_propagate(False)

        # =================================================
        # QUEUE PANEL
        # =================================================

        self.queue_panel = QueuePanel(
            self.right_panel
        )

        self.queue_panel.pack(
            fill="x",
            padx=10,
            pady=10
        )

        # =================================================
        # PERFORMANCE PANEL
        # =================================================

        self.performance_panel = PerformancePanel(
            self.right_panel
        )

        self.performance_panel.pack(
            fill="x",
            padx=10,
            pady=(0, 10)
        )
        
        self.last_queue_size = 0
        self.start_ui_queue_loop()

        

    def start_ui_queue_loop(self):

        process_ui_queue()
        self.update_selected_count()
        self.queue_panel.refresh_queue()

        current_size = len(app_state.image_paths)

        if current_size != self.last_queue_size:

            self.queue_panel.refresh_queue()

            self.last_queue_size = current_size

        self.after(
            300,
            self.start_ui_queue_loop
        )
    # =====================================================
    # ADD IMAGES
    # =====================================================

    def add_images(self):

        file_paths = filedialog.askopenfilenames(
            filetypes=[
                (
                    "Images",
                    "*.png *.jpg *.jpeg *.webp"
                )
            ]
        )

        if not file_paths:
            return

        app_state.image_paths.extend(
            file_paths
        )
        for path in file_paths:

            app_state.queue.append(path)

            app_state.task_status[path] = "waiting"

        threaded_update_preview(
            app_state.image_paths,
            self.preview_container
        )

    # =====================================================
    # DELETE SELECTED
    # =====================================================

    def delete_selected(self):

        selected = list(
            app_state.selected_images
        )

        if not selected:
            return

        for image_path in selected:

            if image_path in app_state.image_paths:

                app_state.image_paths.remove(
                    image_path
                )

        app_state.selected_images.clear()

        threaded_update_preview(
            app_state.image_paths,
            self.preview_container
        )

        self.update_selected_count()

    # =====================================================
    # UPDATE SELECTED COUNT
    # =====================================================

    def update_selected_count(self):

        count = len(
            app_state.selected_images
        )

        self.selected_count_label.configure(
            text=f"Selected: {count}"
        )
    # =====================================================
    # COMPARE SELECTED
    # =====================================================

    def compare_selected(self):

        selected = list(
            app_state.selected_images
        )

        if len(selected) != 2:

            print(
                "Select exactly 2 images"
            )

            return

        compare_window = ctk.CTkToplevel(
            self
        )

        compare_window.title(
            "TSNOVA Compare"
        )

        compare_window.geometry(
            "1200x700"
        )

        slider = CompareSlider(
            compare_window,
            selected[0],
            selected[1]
        )

        slider.pack(
            fill="both",
            expand=True
        )
    # =====================================================
    # EXPORT SELECTED
    # =====================================================

    def export_selected(self):

        selected = list(
            app_state.selected_images
        )

        if not selected:
            return

        export_folder = filedialog.askdirectory()

        if not export_folder:
            return

        for image_path in selected:

            try:

                filename = os.path.basename(
                    image_path
                )

                destination = os.path.join(
                    export_folder,
                    filename
                )

                shutil.copy2(
                    image_path,
                    destination
                )

            except Exception as e:

                print(
                    f"Export Error: {e}"
                )

        print(
            f"Exported {len(selected)} images"
        )
    # =====================================================
    # RETRY SELECTED
    # =====================================================

    def retry_selected(self):

        selected = list(
            app_state.selected_images
        )

        if not selected:
            return

        for image_path in selected:

            app_state.queue.append(
                image_path
            )

            app_state.task_status[
                image_path
            ] = "waiting"

        self.queue_panel.refresh_queue()

        print(
            f"Retry queued: {len(selected)}"
        )