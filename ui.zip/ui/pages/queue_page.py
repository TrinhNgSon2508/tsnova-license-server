import customtkinter as ctk


class QueuePage(ctk.CTkFrame):

    def __init__(self, parent):
        super().__init__(parent)

        label = ctk.CTkLabel(
            self,
            text="Queue",
            font=("Arial", 30, "bold")
        )

        label.pack(pady=40)