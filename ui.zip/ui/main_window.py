import customtkinter as ctk

from ui.app_shell import AppShell


def main(root):

    ctk.set_appearance_mode("dark")

    ctk.set_default_color_theme("blue")

    root.title("TSNOVA")

    root.geometry("1600x950")

    root.minsize(1200, 800)

    AppShell(root)


if __name__ == "__main__":

    root = ctk.CTk()

    main(root)

    root.mainloop()