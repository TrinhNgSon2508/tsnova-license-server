import customtkinter as ctk


class Sidebar(ctk.CTkFrame):

    def __init__(self, parent, on_page_changed):
        super().__init__(parent, width=220)

        self.pack_propagate(False)

        self.on_page_changed = on_page_changed

        # TITLE

        title = ctk.CTkLabel(
            self,
            text="TSNOVA",
            font=("Arial", 28, "bold")
        )

        title.pack(
            pady=(30, 40)
        )

        # NAV BUTTONS

        self.create_nav_button(
            "Dashboard",
            "dashboard"
        )

        self.create_nav_button(
            "Preview",
            "preview"
        )

        self.create_nav_button(
            "Queue",
            "queue"
        )

        self.create_nav_button(
            "Settings",
            "settings"
        )

    def create_nav_button(
        self,
        text,
        page
    ):

        btn = ctk.CTkButton(
            self,
            text=text,
            height=45,
            command=lambda: self.on_page_changed(page)
        )

        btn.pack(
            fill="x",
            padx=15,
            pady=8
        )